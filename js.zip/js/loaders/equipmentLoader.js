// 装備select生成
export async function loadEquipment() {

  const res = await fetch("data/equipment.json")
  const data = await res.json()

  const equipmentList = [
    "kubi",
    "yubi",
    "mune",
    "hoka",
    "monshou",
    "akasi",
    "kokoro"
  ]

  equipmentList.forEach(id => {
    createSelect(id, data[id])
  })
}

function createSelect(id, list) {

  const select = document.getElementById(id)
  const powerInput = document.getElementById(id + "_power")

  if (!select || !powerInput) return

  list.forEach(item => {
    const option = document.createElement("option")

    option.value = item.value
    option.textContent = item.name
    option.dataset.power = item.power

    select.appendChild(option)
  })

  select.addEventListener("change", () => {

    const selected = select.options[select.selectedIndex]

    powerInput.value = selected.dataset.power

    calculate_status()
    calculate_ratio()
  })

  if (select.options.length > 0) {
    powerInput.value = select.options[0].dataset.power
  }
}