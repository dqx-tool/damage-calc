import { mergeArray, mergeObject } from "../utils.js"

// 占い師専用処理
export function applyTarotDefaults(data) {

  if (!data["占い師"]) return

  const tarotDefaults = {
    applicable: [
      "tarot_100P_damage_up_P",
      "tarot_160P_damage_up_P",
      "tarot_kon_damage_up_P",
      "suishou_damage_up_P"
    ],

    auto_select: {
      "tarot_100P_damage_up_P": "3",
      "tarot_160P_damage_up_P": "0.5",
      "suishou_damage_up_P": "2"
    }
  }

  data["占い師"].forEach(skill => {

    mergeArray(
      skill,
      "applicable",
      tarotDefaults.applicable
    )

    mergeObject(
      skill,
      "auto_select",
      tarotDefaults.auto_select
    )

  })

}