// 固定データ

// disable にする候補(applicable に追加すれば除外される)
export const targets = [
  // 呪文系
  "maryoku_damage_up_P",
  "mirazo_damage_up_P",
  "wand_150_damage_up_P",
  "reimyaku_damage_up_E",
  "bukimi_damage_up_E",

  // タロット系
  "tarot_100P_damage_up_P",
  "tarot_160P_damage_up_P",
  "tarot_kon_damage_up_P",
  "suishou_damage_up_P",

  // 一部の特技系
  "damage_up_P_bonus",
  "thanatos_damage_up_P",
  "shuzoku_damage_up_P",
  "force_damage_up_P",

  // テンション系
  "tension_tension_P",
  "mugen_tension_plus_P",
  "kabu_tension_plus_P",
  "bu_lance_tension_plus_P",
  "bougu_tension_plus_P",
  "other_tension_plus_P",

  // スキル、宝珠Lv系
  "houju_spell_Lv_P",
  "sinzui_Lv_P",
  "spell_weapon_skill_Lv_P",
  "spell_job_skill_Lv_P",
  "skill_Lv_P",
  "houju_Lv_P",
  "houju_tarot_Lv_P",

  // その他
  "left_hand",
  "kaisin"
]

// 使用パラメータ → 入力ID対応
export const paramMap = {
  mp: ["mp", "tokugi_plus", "kaisin_plus", "buff_count", "debuff_count"],
  kougeki: ["kougekiR", "kougekiL", "tikara", "shubi", "nitou", "bukiL_power", "baiki", "gasin", "singun", "tokugi_plus", "kaisin_plus", "buff_count", "debuff_count"],
  shubi: ["shubi", "tokugi_plus", "kaisin_plus", "buff_count", "debuff_count"],
  kouma: ["kouma", "tokugi_plus", "kaisin_plus", "buff_count", "debuff_count"],
  kaima: ["kaima", "tokugi_plus", "kaisin_plus", "buff_count", "debuff_count"],
  kiyousa: ["kiyousa", "tokugi_plus", "kaisin_plus", "buff_count", "debuff_count"],
  osharesa: ["osharesa", "tokugi_plus", "kaisin_plus", "buff_count", "debuff_count"],
  N: ["kougekiR", "kougekiL", "tikara", "shubi", "nitou", "bukiL_power", "baiki", "gasin", "singun", "shubi_E", "enemy", "debuff", "tokugi_plus", "kaisin_plus", "buff_count", "debuff_count"]
}