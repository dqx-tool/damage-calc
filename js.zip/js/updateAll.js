import { getSkillData } from "./skill/skillData.js"

import { updateBaikiBaseInputs } from "./ui/baiki.js"

import { updateSkillApplicable } from "./ui/applicable.js"

import { updateParamInputs } from "./ui/paramInputs.js"

import { updateResultLayout } from "./ui/resultLayout.js"

import { calculate } from "./calc/damage/damageCalc.js"


export function updateAll() {

  const skill = getSkillData()

  if (!skill) return

  updateBaikiBaseInputs()

  updateSkillApplicable()

  updateParamInputs(skill)

  updateResultLayout(skill)

  calculate()
}