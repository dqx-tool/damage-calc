import { getUsedParams } from "../skill/usedParams.js"
import { val } from "../utils.js"
import { paramMap } from "../constants.js"

// 入力欄を有効/無効切り替え
export function updateParamInputs(skill) {
  if (!skill) return

  const usedParams = getUsedParams(skill)

  // 左手状態取得
  const leftHand =
    document.getElementById("left_hand").checked

  // 会心状態取得
  const kaisin_check =
    document.getElementById("kaisin").checked

  // バイキ状態
  const baiki = val("baiki")

  // 鉄壁の進軍状態
  const singun = val("singun")

  // スキルの会心タイプ(-1なら通常攻撃)
  const kaisin_type = skill.kaisin || 0

  // 一旦すべてdisabled
  Object.values(paramMap)
    .flat()
    .forEach(id => {

      const el = document.getElementById(id)

      if (el) {
        el.disabled = true
      }

    })

  // 必要パラメータのみ有効
  usedParams.forEach(p => {
    paramMap[p].forEach(id => {
      // 左手なしなら kougekiL を無効のままにする
      if (id === "kougekiL" && !leftHand) return
      if (id === "nitou" && !leftHand) return
      if (id === "bukiL_power" && !leftHand) return

      // バイキなしなら tikara を無効のままにする
      if (id === "tikara" && baiki === 0) return
      if (id === "bukiL_power" && baiki === 0) return

      // 会心なしなら kaisin_plus を無効のままにする
      if (id === "kaisin_plus" && !kaisin_check) return

      // 鉄壁の進軍なしなら shubi を無効のままにする
      if (id === "shubi" && singun === 0) return

      // 通常攻撃なら tokugi_plus を無効のままにする
      if (id === "tokugi_plus" && kaisin_type === -1) return

      // バフ非依存なら buff_count を無効のままにする
      if (id === "buff_count" && !skill.buff_ratio_formula && !skill.buff_ratio_formula_ratio) return

      // デバフ非依存なら debuff_count を無効のままにする
      if (id === "debuff_count" && !skill.debuff_ratio_formula && !skill.debuff_ratio_formula_ratio) return

      const el = document.getElementById(id)

      if (el) {
        el.disabled = false
      }
    })
  })
}