import { getSkillData } from "../skill/skillData.js"
import { targets } from "../constants.js"

// json に applicable という項目があれば選択可能
export function updateSkillApplicable() {

  const skill = getSkillData()
  if (!skill) return

  const applicable = skill.applicable || []
  targets.forEach(id => {
    const el = document.getElementById(id)
    if (!el) return

    const enabled = applicable.includes(id)
    el.disabled = !enabled

    // checkbox連動
    const cb = document.querySelector(`input[data-target="${id}"]`)
    if (cb) {
      cb.disabled = !enabled
    }

    // Maxボタンなど
    const btn = document.querySelector(`[data-max="${id}"]`)
    if (btn) {
      btn.disabled = !enabled
    }

  })

}