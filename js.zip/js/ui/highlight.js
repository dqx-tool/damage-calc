// 各種補正が適用されていれば色を変える
export function setupTableBuffHighlight(tableSelector) {
  const tables = document.querySelectorAll(tableSelector)

  tables.forEach(table => {
    const rows = table.querySelectorAll("tr")

    rows.forEach(row => {

      function update() {
        let active = false

        const select = row.querySelector("select")
        const checkbox = row.querySelector("input[type='checkbox']")
        const inputs = row.querySelectorAll("input[type='number']")

        // select判定
        if (select) {

          // manual は常にON
          if (select.value === "manual") {
            active = true
          }

          // 数値として解釈できる場合
          else if (!isNaN(parseFloat(select.value))) {

            const val = parseFloat(select.value)

            if (val !== 0) {
              active = true
            }
          }

          // 文字列value (thanatosなど)
          else if (select.value !== "0" && select.value !== "") {
            active = true
          }
        }

        // input判定（複数対応）
        inputs.forEach(input => {
          if (!input.readOnly) {
            const val = parseFloat(input.value)
            if (!isNaN(val) && val !== 0) active = true
          }
        })

        // checkbox判定
        if (checkbox && checkbox.checked) {
          active = true
        }

        row.classList.toggle("active-buff", active)

        // 関係ない項目の文字をグレーに
        
      }

      // select
      const select = row.querySelector("select")
      if (select) select.addEventListener("change", update)

      // checkbox
      const checkbox = row.querySelector("input[type='checkbox']")
      if (checkbox) checkbox.addEventListener("change", update)

      // 動的input対応
      table.addEventListener("input", e => {
        if (row.contains(e.target)) {
          update()
        }
      })

      update()
    })
  })
}