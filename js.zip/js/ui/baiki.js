import { val } from "../utils.js"

export function updateBaikiBaseInputs() {

  const baiki = val("baiki")

  const table = document.getElementById("baiki_base_table")

  if (!table) return

  table.querySelectorAll("input, select").forEach(el => {
    el.disabled = (baiki === 0)
  })
}