import { updateAll } from "../updateAll.js"

// 最大 or ファラボタン
export function setupActionButtons() {
  document.addEventListener("click", e => {

    const btn = e.target.closest(".max-btn")
    if (!btn) return

    const id = btn.dataset.max
    if (!id) return

    const el = document.getElementById(id)
    if (!el) return

    // -----------------
    // select の場合
    // -----------------
    if (el.tagName === "SELECT") {

      // offset指定（phalaなど）
      if (btn.dataset.offset !== undefined) {
        const offset = Number(btn.dataset.offset)
        el.selectedIndex = el.options.length + offset
      }

      // 通常max
      else {
        el.selectedIndex = el.options.length - 1
      }

      el.dispatchEvent(new Event("change", { bubbles: true }))
    }

    // -----------------
    // input の場合
    // -----------------
    else if (el.tagName === "INPUT") {

      if (btn.dataset.value !== undefined) {
        el.value = Number(btn.dataset.value)
      }

      el.dispatchEvent(new Event("input", { bubbles: true }))
      el.dispatchEvent(new Event("change", { bubbles: true }))
    }

    updateAll()
  })
}